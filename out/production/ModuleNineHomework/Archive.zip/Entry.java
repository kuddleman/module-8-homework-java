//public class Entry <T> {
//    private T entry;
//
//    public Entry() {
//        this.entry = null;
//    }
//
//}
